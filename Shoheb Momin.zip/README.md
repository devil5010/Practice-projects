# Practice-projects
A responsive static website built with HTML and custom CSS — optimized for all screen sizes.
